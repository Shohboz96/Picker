package com.example.permissionsl13.utils

typealias SingleBlock <T> = (T) -> Unit